#include "CardDeck.h"
#include <utility>

void CardDeck::addCard(const SharedPtr<Card>& card)
{
	cards.push(SharedPtr<Card>(card));
}

const SharedPtr<Card>& CardDeck::drawCard()
{
	const SharedPtr<Card>& cardToReturn = cards.peek();
	cards.pop();

	return cardToReturn;
}
