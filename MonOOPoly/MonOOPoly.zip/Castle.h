#pragma once
#include "Mortgage.h"

class Castle : public Mortgage
{
public:
	Castle(unsigned price);
};

