#pragma once
#include "Mortgage.h"

class Cottage : public Mortgage
{
public:
	Cottage(unsigned price);
};

