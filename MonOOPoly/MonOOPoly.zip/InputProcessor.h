#pragma once
class InputProcessor
{
public:
	static char askYesOrNo();
};

